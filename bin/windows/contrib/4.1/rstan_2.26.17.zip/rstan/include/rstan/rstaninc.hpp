#ifndef RSTAN__RSTANINC_HPP
#define RSTAN__RSTANINC_HPP
#include <stan/math/prim/fun/Eigen.hpp>
#include <rstan/stan_fit.hpp>
#endif

