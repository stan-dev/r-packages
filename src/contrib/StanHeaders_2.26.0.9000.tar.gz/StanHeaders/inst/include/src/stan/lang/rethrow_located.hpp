#ifndef STAN_LANG_RETHROW_LOCATED_HPP
#define STAN_LANG_RETHROW_LOCATED_HPP

#include <stan/model/rethrow_located.hpp>

#endif
