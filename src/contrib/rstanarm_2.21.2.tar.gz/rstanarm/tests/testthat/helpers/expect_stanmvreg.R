expect_stanmvreg  <- function(x) expect_s3_class(x, "stanmvreg")
