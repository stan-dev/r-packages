params <-
list(EVAL = TRUE)

## ----settings-knitr, include=FALSE--------------------------------------------
stopifnot(require(knitr))
opts_chunk$set(
  # collapse = TRUE,
  comment=NA,
  eval = if (isTRUE(exists("params"))) params$EVAL else FALSE
)

## ----install_github, eval=FALSE-----------------------------------------------
#  devtools::install_github("stan-dev/cmdstanr")

## ----library, message=FALSE---------------------------------------------------
library(cmdstanr)

## ---- include = FALSE---------------------------------------------------------
if (!dir.exists(cmdstan_default_path())) {
  install_cmdstan()
}

## ---- eval=FALSE--------------------------------------------------------------
#  install_cmdstan()

## ----set_cmdstan_path, eval=FALSE---------------------------------------------
#  set_cmdstan_path(PATH_TO_CMDSTAN)

## ----cmdstan_path-------------------------------------------------------------
cmdstan_path()
cmdstan_version()

## ----cmdstan_model------------------------------------------------------------
file <- file.path(cmdstan_path(), "examples", "bernoulli", "bernoulli.stan")
mod <- cmdstan_model(file)

## ----compile------------------------------------------------------------------
mod$print()  # print the Stan program

## ----exe_file-----------------------------------------------------------------
mod$exe_file()

## ----sample-------------------------------------------------------------------
data_list <- list(N = 10, y = c(0,1,0,0,0,0,0,0,0,1))
fit <- mod$sample(
  data = data_list, 
  seed = 123, 
  chains = 2, 
  cores = 2
)

## ----summary------------------------------------------------------------------
fit$summary()

## ----draws--------------------------------------------------------------------
# this is a draws_array object from the posterior package
draws <- fit$draws()
str(draws)

## ----sampler_diagnostics------------------------------------------------------
# this is a draws_array object from the posterior package
str(fit$sampler_diagnostics())

## ----summary-and-diagnose-----------------------------------------------------
fit$cmdstan_diagnose()
fit$cmdstan_summary()

## ----stanfit------------------------------------------------------------------
stanfit <- rstan::read_stan_csv(fit$output_files())
print(stanfit)

