library(testthat)
library(cmdstanr)

test_check("cmdstanr")
