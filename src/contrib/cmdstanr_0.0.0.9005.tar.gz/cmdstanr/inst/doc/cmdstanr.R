params <-
list(EVAL = TRUE)

## ----settings-knitr, include=FALSE--------------------------------------------
stopifnot(require(knitr))
opts_chunk$set(
  # collapse = TRUE,
  dev = "png",
  dpi = 150,
  fig.asp = 0.618,
  fig.width = 5,
  out.width = "60%",
  fig.align = "center",
  comment = NA,
  comment=NA,
  eval = if (isTRUE(exists("params"))) params$EVAL else FALSE
)

## ----install, eval=FALSE------------------------------------------------------
#  install.packages("cmdstanr", repos = c("https://mc-stan.org/r-packages/", getOption("repos")))

## ----library, message=FALSE---------------------------------------------------
library(cmdstanr)
library(bayesplot)
library(posterior)

## ---- include = FALSE---------------------------------------------------------
if (!dir.exists(cmdstan_default_path())) {
  install_cmdstan()
}

## ---- eval=FALSE--------------------------------------------------------------
#  install_cmdstan(cores = 2)

## ----set_cmdstan_path, eval=FALSE---------------------------------------------
#  set_cmdstan_path(PATH_TO_CMDSTAN)

## ----cmdstan_path-------------------------------------------------------------
cmdstan_path()
cmdstan_version()

## ----cmdstan_model------------------------------------------------------------
file <- file.path(cmdstan_path(), "examples", "bernoulli", "bernoulli.stan")
mod <- cmdstan_model(file)

## ----compile------------------------------------------------------------------
mod$print()  # print the Stan program

## ----exe_file-----------------------------------------------------------------
mod$exe_file()

## ----sample-------------------------------------------------------------------
data_list <- list(N = 10, y = c(0,1,0,0,0,0,0,0,0,1))
fit <- mod$sample(
  data = data_list, 
  seed = 123, 
  chains = 2, 
  parallel_chains = 2
)

## ----summary------------------------------------------------------------------
fit$summary()

## ----draws, message=FALSE-----------------------------------------------------
# this is a draws_array object from the posterior package
draws_array <- fit$draws()
str(draws_array)

# can be passed directly to bayesplot to plot posterior distribution
mcmc_hist(fit$draws("theta"))

# convert to matrix or data frame 
draws_df <- as_draws_df(draws_array) # as_draws_matrix() for matrix
print(draws_df)

## ----sampler_diagnostics------------------------------------------------------
# this is a draws_array object from the posterior package
str(fit$sampler_diagnostics())

# convert to matrix or data frame using posterior package
diagnostics_df <- as_draws_df(fit$sampler_diagnostics())
print(diagnostics_df)

## ----summary-and-diagnose-----------------------------------------------------
fit$cmdstan_diagnose()
fit$cmdstan_summary()

## ----stanfit------------------------------------------------------------------
stanfit <- rstan::read_stan_csv(fit$output_files())
print(stanfit)

