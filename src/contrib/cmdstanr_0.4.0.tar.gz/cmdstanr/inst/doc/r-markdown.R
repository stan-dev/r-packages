params <-
list(EVAL = TRUE)

## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = if (isTRUE(exists("params"))) params$EVAL else FALSE
)

## ----setup, message=FALSE-----------------------------------------------------
library(cmdstanr)

register_knitr_engine()

## -----------------------------------------------------------------------------
ex1$print()

## ----fit----------------------------------------------------------------------
fit <- ex1$sample(
  refresh = 0,
  seed = 42L
)

print(fit)

