params <-
list(EVAL = TRUE)

## ----settings-knitr, include=FALSE--------------------------------------------
stopifnot(require(knitr))
opts_chunk$set(
  # collapse = TRUE,
  dev = "png",
  dpi = 150,
  fig.asp = 0.618,
  fig.width = 5,
  out.width = "60%",
  fig.align = "center",
  comment = NA,
  eval = if (isTRUE(exists("params"))) params$EVAL else FALSE
)

## ----install, eval=FALSE------------------------------------------------------
#  install.packages("cmdstanr", repos = c("https://mc-stan.org/r-packages/", getOption("repos")))

## ----library, message=FALSE---------------------------------------------------
library(cmdstanr)
library(posterior)
library(bayesplot)
color_scheme_set("brightblue")

## ----check-toolchain----------------------------------------------------------
check_cmdstan_toolchain()

## ----install_cmdstan-1, include = FALSE---------------------------------------
if (!dir.exists(cmdstan_default_path())) {
  install_cmdstan()
}

## ----install_cmdstan-2, eval=FALSE--------------------------------------------
#  install_cmdstan(cores = 2)

## ----set_cmdstan_path, eval=FALSE---------------------------------------------
#  set_cmdstan_path(PATH_TO_CMDSTAN)

## ----cmdstan_path-------------------------------------------------------------
cmdstan_path()
cmdstan_version()

## ----cmdstan_model------------------------------------------------------------
file <- file.path(cmdstan_path(), "examples", "bernoulli", "bernoulli.stan")
mod <- cmdstan_model(file)

## ----compile------------------------------------------------------------------
mod$print()

## ----exe_file-----------------------------------------------------------------
mod$exe_file()

## ----sample-------------------------------------------------------------------
# names correspond to the data block in the Stan program
data_list <- list(N = 10, y = c(0,1,0,0,0,0,0,0,0,1))

fit <- mod$sample(
  data = data_list, 
  seed = 123, 
  chains = 4, 
  parallel_chains = 2,
  refresh = 500
)

## ----summary------------------------------------------------------------------
fit$summary()
fit$summary("theta", "mean", "sd")

# use a formula to summarize arbitrary functions, e.g. Pr(theta <= 0.5)
fit$summary("theta", pr_lt_half = ~ mean(. <= 0.5))

## ----draws, message=FALSE-----------------------------------------------------
# this is a draws_array object from the posterior package
draws_array <- fit$draws()
str(draws_array)

# convert to matrix or data frame 
draws_df <- as_draws_df(draws_array) # as_draws_matrix() for matrix
print(draws_df)

## ----plots, message=FALSE-----------------------------------------------------
mcmc_hist(fit$draws("theta"))

## ----sampler_diagnostics------------------------------------------------------
# this is a draws_array object from the posterior package
str(fit$sampler_diagnostics())

# convert to matrix or data frame using posterior package
diagnostics_df <- as_draws_df(fit$sampler_diagnostics())
print(diagnostics_df)

## ----summary-and-diagnose-----------------------------------------------------
fit$cmdstan_diagnose()
fit$cmdstan_summary()

## ----stanfit, eval=FALSE------------------------------------------------------
#  stanfit <- rstan::read_stan_csv(fit$output_files())

## ----optimize-----------------------------------------------------------------
fit_mle <- mod$optimize(data = data_list, seed = 123) 
fit_mle$summary() # includes lp__ (log prob calculated by Stan program)
fit_mle$mle("theta") 

## ----plot-mle, message = FALSE------------------------------------------------
mcmc_hist(fit$draws("theta")) + 
  vline_at(fit_mle$mle(), size = 1.5)

## ----variational--------------------------------------------------------------
fit_vb <- mod$variational(data = data_list, seed = 123, output_samples = 4000) 
fit_vb$summary("theta")

## ----plot-variational, message = FALSE----------------------------------------
bayesplot_grid(
  mcmc_hist(fit$draws("theta"), binwidth = 0.025),    
  mcmc_hist(fit_vb$draws("theta"), binwidth = 0.025),
  titles = c("Posterior distribution from MCMC", "Approximate posterior from VB"),
  xlim = c(0, 1)
)

## ----save_object, eval=FALSE--------------------------------------------------
#  fit$save_object(file = "fit.RDS")
#  
#  # can be read back in using readRDS
#  fit2 <- readRDS("fit.RDS")

