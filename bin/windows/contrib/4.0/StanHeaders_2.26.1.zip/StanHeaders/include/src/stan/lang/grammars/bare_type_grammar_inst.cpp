#include <stan/lang/grammars/bare_type_grammar_def.hpp>
#include <stan/lang/grammars/iterator_typedefs.hpp>

namespace stan {

namespace lang {

template struct stan::lang::bare_type_grammar<pos_iterator_t>;
}

}  // namespace stan
