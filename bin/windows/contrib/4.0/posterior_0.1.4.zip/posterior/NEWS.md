# posterior 0.1.0

* beta release
