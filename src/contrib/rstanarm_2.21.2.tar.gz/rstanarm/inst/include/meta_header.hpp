#ifndef RSTANARM__META_HEADER_HPP
#define RSTANARM__META_HEADER_HPP

#include "csr_matrix_times_vector2.hpp"
#endif
