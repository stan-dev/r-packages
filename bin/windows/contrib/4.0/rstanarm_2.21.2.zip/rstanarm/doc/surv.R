params <-
list(EVAL = TRUE)

## ---- SETTINGS-knitr, include=FALSE-------------------------------------------
stopifnot(require(knitr))
opts_chunk$set(
  comment=NA, 
  message = FALSE, 
  warning = FALSE, 
  eval = identical(Sys.getenv("NOT_CRAN"), "true"),
  dev = "png",
  dpi = 150,
  fig.asp = 0.618,
  fig.width = 5,
  out.width = "60%",
  fig.align = "center"
)

## ---- SETTINGS-gg, include=TRUE-----------------------------------------------
library(ggplot2)
library(bayesplot)
theme_set(bayesplot::theme_default())

## ----setup_jm, include=FALSE, message=FALSE-----------------------------------
knitr::opts_chunk$set(fig.width=10, fig.height=4)
library(rstanarm)
set.seed(989898)

CHAINS <- 1
CORES  <- 1
SEED   <- 12345
ITER   <- 1000

## ---- warning = FALSE, message = FALSE, results='hide'------------------------
mod1 <- stan_surv(formula = Surv(recyrs, status) ~ group, 
                  data    = bcancer, 
                  chains  = CHAINS, 
                  cores   = CORES, 
                  seed    = SEED,
                  iter    = ITER)

## -----------------------------------------------------------------------------
print(mod1, digits = 3)

## ---- warning = FALSE, message = FALSE, results='hide'------------------------
mod1_exp      <- update(mod1, basehaz = "exp")
mod1_weibull  <- update(mod1, basehaz = "weibull")
mod1_gompertz <- update(mod1, basehaz = "gompertz")
mod1_bspline  <- update(mod1, basehaz = "bs")
mod1_mspline1 <- update(mod1, basehaz = "ms")
mod1_mspline2 <- update(mod1, basehaz = "ms", basehaz_ops = list(df = 10))

## ---- fig.height=5------------------------------------------------------------
library(ggplot2)

plotfun <- function(model, title) {
  plot(model, plotfun = "basehaz") +              # plot baseline hazard
    coord_cartesian(ylim = c(0,0.4)) +            # adjust y-axis limits
    labs(title = title) +                         # add plot title
    theme(plot.title = element_text(hjust = 0.5)) # centre plot title
}

p_exp      <- plotfun(mod1_exp,      title = "Exponential")
p_weibull  <- plotfun(mod1_weibull,  title = "Weibull")
p_gompertz <- plotfun(mod1_gompertz, title = "Gompertz")
p_bspline  <- plotfun(mod1_bspline,  title = "B-splines with df = 5")
p_mspline1 <- plotfun(mod1_mspline1, title = "M-splines with df = 5")
p_mspline2 <- plotfun(mod1_mspline2, title = "M-splines with df = 10")

bayesplot::bayesplot_grid(p_exp,
                          p_weibull,
                          p_gompertz,
                          p_bspline,
                          p_mspline1,
                          p_mspline2,
                          grid_args = list(ncol = 3))

## ---- message=FALSE-----------------------------------------------------------
loo_compare(loo(mod1_exp),
            loo(mod1_weibull),
            loo(mod1_gompertz),
            loo(mod1_bspline),
            loo(mod1_mspline1),
            loo(mod1_mspline2))

## ----preddata-----------------------------------------------------------------
nd <- data.frame(group = c("Good", "Medium", "Poor"))
head(nd)

## ----predresults--------------------------------------------------------------
ps <- posterior_survfit(mod1, newdata = nd, times = 0, extrapolate = TRUE,
                        control = list(edist = 5))
head(ps)

## ----predplot-----------------------------------------------------------------
panel_labels <- c('1' = "Good", '2' = "Medium", '3' = "Poor")
plot(ps) + 
  ggplot2::facet_wrap(~ id, labeller = ggplot2::labeller(id = panel_labels))

## ----predhaz------------------------------------------------------------------
ph <- posterior_survfit(mod1, newdata = nd, type = "haz")
plot(ph) + 
  ggplot2::facet_wrap(~ id, labeller = ggplot2::labeller(id = panel_labels))

## ----simsurv-simdata----------------------------------------------------------
# load package
library(simsurv)

# set seed for reproducibility
set.seed(999111)

# simulate covariate data
covs <- data.frame(id  = 1:200, 
                   trt = rbinom(200, 1L, 0.5))

# simulate event times
dat  <- simsurv(lambdas = 0.1, 
                gammas  = 1.5, 
                betas   = c(trt = -0.5),
                tde     = c(trt = 0.2),
                x       = covs, 
                maxt    = 5)

# merge covariate data and event times
dat  <- merge(dat, covs)

# examine first few rows of data
head(dat)

## ----tve_fit1, warning = FALSE, message = FALSE, results='hide'---------------
mod2 <- stan_surv(formula = Surv(eventtime, status) ~ tve(trt), 
                  data    = dat, 
                  chains  = CHAINS, 
                  cores   = CORES, 
                  seed    = SEED,
                  iter    = ITER)

## ---- warning = FALSE, message = FALSE, results='hide', eval=FALSE------------
#  Surv(eventtime, status) ~ tve(trt, df = 4, degree = 2)

## ---- fig.height=5------------------------------------------------------------
plot(mod2, plotfun = "tve")

## ----simsurv-simdata2---------------------------------------------------------
# load package
library(simsurv)

# set seed for reproducibility
set.seed(888222)

# simulate covariate data
covs <- data.frame(id  = 1:500, 
                   trt = rbinom(500, 1L, 0.5))

# simulate event times
dat  <- simsurv(lambdas = 0.1, 
                gammas  = 1.5, 
                betas   = c(trt = -0.5),
                tde     = c(trt = 0.7),
                tdefun  = function(t) (t > 2.5),
                x       = covs, 
                maxt    = 5)

# merge covariate data and event times
dat  <- merge(dat, covs)

# examine first few rows of data
head(dat)

## ----tve-fit2, warning = FALSE, message = FALSE, results='hide'---------------
mod3 <- stan_surv(formula = Surv(eventtime, status) ~ 
                    tve(trt, degree = 0, knots = 2.5),
                  data    = dat, 
                  chains  = CHAINS, 
                  cores   = CORES, 
                  seed    = SEED,
                  iter    = ITER)

## ---- fig.height=5------------------------------------------------------------
plot(mod3, plotfun = "tve")

## ----frail-data-head----------------------------------------------------------
head(frail)

## ----frail-fit-model, warning = FALSE, message = FALSE------------------------
mod_randint <- stan_surv(
  formula = Surv(eventtime, status) ~ trt + (1 | site),
  data    = frail,
  basehaz = "exp",
  chains  = CHAINS, 
  cores   = CORES, 
  seed    = SEED,
  iter    = ITER)

## ----frail-estimates----------------------------------------------------------
print(mod_randint, digits = 2)

## ----frail-fixed-model, warning = FALSE, message = FALSE----------------------
mod_fixed <- update(mod_randint, formula. = Surv(eventtime, status) ~ trt) 

## ----frail-compare-1, warning = FALSE, message = FALSE------------------------
loo_fixed   <- loo(mod_fixed)
loo_randint <- loo(mod_randint)
loo_compare(loo_fixed, loo_randint)

## ----frail-random-trt, warning = FALSE, message = FALSE-----------------------
mod_randtrt <- update(mod_randint, formula. = 
                        Surv(eventtime, status) ~ trt + (trt | site)) 
print(mod_randtrt, digits = 2)

## ----frail-compare-2, warning = FALSE, message = FALSE------------------------
loo_randtrt <- loo(mod_randtrt)
loo_compare(loo_fixed, loo_randint, loo_randtrt)

