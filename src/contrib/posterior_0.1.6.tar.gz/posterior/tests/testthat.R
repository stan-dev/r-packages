library(testthat)
library(posterior)
library(caret)

test_check("posterior")
