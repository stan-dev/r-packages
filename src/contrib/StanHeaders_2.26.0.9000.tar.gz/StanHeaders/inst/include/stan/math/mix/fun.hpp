#ifndef STAN_MATH_MIX_FUN_HPP
#define STAN_MATH_MIX_FUN_HPP

#include <stan/math/mix/fun/typedefs.hpp>

#endif
